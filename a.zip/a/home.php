<!DOCTYPE html>
<html>
<head>
<style> 
.flex-container {
    display: -webkit-flex;
    display: flex;  
    -webkit-flex-flow: row wrap;
    flex-flow: row wrap;
    text-align: center;
}

.flex-container > * {
    padding: 15px;
    -webkit-flex: 1 100%;
    flex: 1 100%;
}

.container {
      padding: 30px 120px;
  }

.article {
    text-align: left;

}

.article lala {
    text-align: center;
}


header {background: #4F4C4B;color:white;}
footer {background: #4F4C4B;color:white;}
.nav {background:#9CC8B4;}

.nav ul {
    list-style-type: none;
    padding: 0;
}
.nav ul a {
    text-decoration: underline;

}

@media all and (min-width: 768px) {
    .nav {text-align:left;-webkit-flex: 1 auto;flex:1 auto;-webkit-order:1;order:1;}
    .article {-webkit-flex:5 0px;flex:5 0px;-webkit-order:2;order:2;}
    footer {-webkit-order:3;order:3;}
}
</style>
</head>
<body>

<div class="flex-container">
<header>
  <h1>Tutorial</h1>
</header>

<nav class="nav">
<p>Coverage:</p>
<ul>
  <li><a href="#one">Types of Is</a></li>
  <li><a href="#two">3-tier Architecture</a></li>
  <li><a href="#three">Level of IS</a></li>
  <li><a href="#four">IS Infrastucture</a></li>
  <li><a href="#five">Communication Tools</a></li>
</ul>
</nav>

<article class="article">
  <div id="one" data-spy="scroll" class="container">
  <h1>Types of IS</h1>
  <p>1. Transaction Processing System (TPS)</p>
  <p><i>  What is a Transaction Processing System?</i></p>
  <p> A Transaction Processing System (TPS) is a type of information system that collects, stores, modifies and retrieves the data transactions of an enterprise. </p>

  <p> A transaction is any event that passes the ACID test in which data is generated or modified before storage in an information system </p>
  <p> Transaction Processing System are operational-level systems at the bottom of the pyramid. They are usually operated directly by shop floor workers or front line staff, which provide the key data required to support the management of operations. This data is usually obtained through the automated or semi-automated tracking of low-level activities and basic transactions.</p>

  <p><i>  Functions of a TPS</i></p>
  <p>TPS are ultimately little more than simple data processing systems.</p>
<table width="100%" border="2" title="Functions of a TPS">
<caption>Functions of a TPS in terms of data processing requirements</caption>
<col width="30%" span="3">
<tr>
<td>Inputs</td>
<td>Processing</td>
<td>Outputs</td>
</tr>
<tr>
<td>Transactions<br>
Events</td>
<td>Validation<br>
Sorting<br>
Listing<br>
Merging<br>
Updating<br>
Calculation</td>
<td>Lists<br>
Detail reports<br>
Action reports<br>
Summary reports?</td>
</tr>
</table>

<p><i>Some examples of TPS</i></p>
<ul>
<li>Payroll systems</li>
<li>Order processing systems</li>
<li>Reservation systems</li>
<li>Stock control systems</li>
<li>Systems for payments and funds transfers</li>
</ul>
<p><i>The role of TPS</i></p>
<ul>
<li>Produce information for other systems</li>
<li>Cross boundaries (internal and external)</li>
<li>Used by operational personnel + supervisory levels</li>
<li>Efficiency oriented</li>
</ul>
<br></li>

  <p>2. Decision Support System (DSS)</p>
  <p><i>  What is a Decision Support System?</i></p>
  <p>A Decision Support System can be seen as a knowledge based system, used by senior managers, which facilitates the creation of knowledge and allow its integration into the organization. These systems are often used to analyze existing structured information and allow managers to project the potential effects of their decisions into the future. Such systems are usually interactive and are used to solve ill structured problems. They offer access to databases, analytical tools, allow "what if" simulations, and may support the exchange of information within the organization. </p>

  <p> A properly designed Decision Support System is an interactive software-based system intended to help decision makers compile useful information from raw data, documents, personal knowledge, and/or business models to identify and solve problems and make decisions.</p>
  

  <p><i>  Functions of a TPS</i></p>
  <p>DSS manipulate and build upon the information from a MIS and/or TPS to generate insights and new information.</p>

  <table width="100%" border="2" title="Functions of a DSS">
<caption>Functions of a DSS in terms of data processing requirements</caption>
<col width="30%" span="3">
<tr>
<td>Inputs</td>
<td>Processing</td>
<td>Outputs</td>
</tr>
<tr>
<td>Internal Transactions<br>
Internal Files<br>
External Information?</td>
<td>Modelling<br>
Simulation<br>
Analysis<br>
Summarizing</td>
<td>Summary reports<br>
Forecasts<br>
Graphs / Plots</td>
</tr>
</table>
  
  <p><i>Some examples of DSS</i></p>
<ul>
<li>Group Decision Support Systems (GDSS)</li>
<li>Computer Supported Co-operative work (CSCW)</li>
<li>Logistics systems</li>
<li>Financial Planning systems</li>
<li>Spreadsheet Models?</li>
</ul>
<p><i>The role of DSS</i></p>
<ul>
<li>Support ill- structured or semi-structured decisions</li>
<li>Have analytical and/or modelling capacity</li>
<li>Used by more senior managerial levels</li>
<li>Are concerned with predicting the future</li>
<li>Are effectiveness oriented?</li>
</ul>
<br></li>

  <p>3. Expert System (ES)</p>
  <p><i>  What is an Expert System?</i></p>
  <p> Expert system is an artificial intelligence program that has expert-level knowledge about a particular domain and knows how to use its knowledge to respond properly. Domain refers to the area within which the task is being performed. Ideally the expert systems should substitute a human expert. Edward Feigenbaum of Stanford University has defined expert system as an intelligent computer program that uses knowledge and inference procedures to solve problems that are difficult enough to require significant human expertise for their solutions. It is a branch of artificial intelligence introduced by researchers in the Stanford Heuristic Programming Project.</p>

<br>
  </div>

  <div id="two" class="container">
  <h1>3-Tier Architecture</h1>
  <p>A 3-tier architecture separates its tiers from each other based on the complexity of the users and how they use the data present in the database. It is the most widely used architecture to design a DBMS.</p>
  <center><img src="img/tier.png"></center>

  <h1>Tier 1</h1>
  <p><strong>Database Tier</strong></p>
  <p>The database tier is the base of a web database application. Understanding system requirements, choosing database-tier software, designing databases, and building the tier are the first steps in successful web database application development. We discuss techniques for modeling system requirements, converting a model into a database, and the principles of database technology in Appendix C. In this section, we focus on the components of the database tier and introduce database software by contrasting it with other techniques for storing data. Chapter 3 covers the standards and software we use in more detail.</p>
  <p>In a three-tier architecture application, the database tier manages the data. The data management typically includes storage and retrieval of data, as well as managing updates, allowing simultaneous, or concurrent, access by more than one middle-tier process, providing security, ensuring the integrity of data, and providing support services such as data backup. In many web database applications, these services are provided by a RDBMS system, and the data stored in a relational database.</p>

  <h1>Tier 2</h1>
  <p><strong>Application Tier</strong></p>
  <p>One of the key elements of any application design is the system architecture. The system architecture defines how pieces of the application interact with each other, and what functionality each piece is responsible for performing. There are three main classes of application architecture. They can be characterized by the number of layers between the user and the data. Each layer generally runs on a different system or in a different process space on the same system than the other layers. The three types of application architecture are single-tier (or monolithic), two-tier, and n-tier, where n can be three or more.</p>
  <p>The monolithic application consists of a single application layer that supports the user interface, the business rules, and the manipulation of the data all in one. The data itself could be physically stored in a remote location, but the logic for accessing it is part of the application. Microsoft Word is an example of a monolithic application. The user interface is an integral part of the application. The business rules, such as how to paginate and hyphenate, are also part of the application. The file access routines, to manipulate the data of the document, are also part of the application. Even if there are multiple DLLs that handle the different functionality, it is still a monolithic application.</p>
  <p>In a two-tier application, the business rules and user interface remain as part of the client application. The data retrieval and manipulation is performed by another separate application, usually found on a physically separate system. This separate application could be something like SQL Server or Oracle, which is functioning as a data storage device for the application. This type of application is widely used in the traditional client-server types of applications. PowerBuilder or Visual Basic both integrating with Oracle are two examples of tools that can be used to create client-server systems.</p>

  <h1>Tier 3</h1>
  <p><strong>Presentation Tier</strong></p>
  <p>In a three-tier application, the presentation tier is the logical group of components that provide a user interface. These component can include Uniface server pages, forms, and reports, as well as non-Uniface components such as JavaServer pages and Microsoft’s Active Server Pages.</p>
  <p>Presentation tier components allow users to interact with the application, but they do not process data, handle business rules, or directly access databases or other storage media.</p>
  <p>This has implications for how the data is validated before it is submitted to the business tier and stored in the database. When developing presentation tier components, you are advised to use declarative validation using development object properties, rather than procedural validation using Proc code. This ensures that the data is substantially correct before it is submitted to the business tier, which reduces network traffic and server overhead, and is also more user-friendly. Procedural validation enforces business rules in the business logic tier, which can result in a lot of unnecessary processing and network traffic if the submitted data is incorrect.</p>
  <p>End-users operate on this tier and they know nothing about any existence of the database beyond this layer. At this layer, multiple views of the database can be provided by the application. All views are generated by applications that reside in the application tier.</p>
  </div>
  <br><br>
  <div id="three" class="container">
  <h1>Levels of IS</h1>
  <p>Within an organisation planning, control and decision-making is carried out at various levels within the structure of the organisation.</p>
  <center><img src="img/lvl.png"></center>
  <p><i>Strategic</i></p>
  <p>Strategic information is used at the very top level of management within an organisation. These are chief executives or directors who have to make decisions for the long term.</p>
  <p><i>Tactical</i></p>
  <p>Tactical information will be mostly internal with a few external sources being used.  Internal information is likely to be function related: for example, how much ‘down time’ a production line must allocate for planned maintenance.</p>
  <p><i>Operational</i></p>
  <p>The lowest level of management or workers in an organisation implements operational plans.  These may be section leaders or foremen in a large organisation or workers such as shop assistants, waiting staff, and kitchen staff, etc., in smaller businesses where there is no supervisory layer.</p>
  </div>

  <div id="four" class="container">
  <h1> IS Infrastructure</h1>
  <p>Infrastructure is the foundation or framework that supports a system or organization. In computing, infrastructure is composed of physical and virtual resources that support the flow, storage, processing and analysis of data. Infrastructure may be centralized within a data center, or it may be decentralized and spread across several data centers that are either controlled by the organization or by a third party, such as a colocation facility or cloud provider.</p>
  <center><img src="img/is.jpg"></center>
  </div>

  <div id="five" class="container">
  <h1>Online Communication Tools</h1>
  <p><strong>Blogs</strong></p>
  <center><img src="img/blog.jpg" height="250" width="300"></center>
  <p>In contrast to a traditional website which may be updated irregularly, a BLOG is usually updated frequently, maybe weekly, daily, or even several times a day, it all depends on the blogger. Depending on the topics which the blog covers, a blog could probably be considered stale if it was not updated for several months. </p>
  <p>One reason for the massive surge in published blogs is the simplicity of its software. Most blogging applications make it very easy to create your own blog with no technical knowledge at all. This has enabled writers from all backgrounds to get their content online. </p>

  <p><strong>Emails</strong></p>
  <center><img src="img/email.png" height="250" width="300"></center>
  <p>E-mail (electronic mail) is the exchange of computer-stored messages by telecommunication. (Some publications spell it email; we prefer the currently more established spelling of e-mail.) E-mail messages are usually encoded in ASCII text. However, you can also send non-text files, such as graphic images and sound files, as attachments sent in binary streams. E-mail was one of the first uses of the Internet and is still the most popular use. A large percentage of the total traffic over the Internet is e-mail. E-mail can also be exchanged between online service provider users and in networks other than the Internet, both public and private. </p>
  <p>Email uses multiple protocols within the TCP/IP suite. For example, SMTP is used to send messages, while the POP or IMAP protocols are used to retrieve messages from a mail server. When you configure an email account, you must define your email address, password, and the mail servers used to send and receive messages.</p>

  <p><strong>Video Conferencing</strong></p>
  <center><img src="img/vc.jpg" height="250" width="300"></center>
  <p>A video conference is a live, visual connection between two or more people residing in separate locations for the purpose of communication. At its simplest, video conferencing provides transmission of static images and text between two locations. At its most sophisticated, it provides transmission of full-motion video images and high-quality audio between multiple locations.</p>
  <p>Multipoint videoconferencing allows three or more participants to sit in a virtual conference room and communicate as if they were sitting right next to each other. Until the mid 90s, the hardware costs made videoconferencing prohibitively expensive for most organizations, but that situation is changing rapidly. Many analysts believe that videoconferencing will be one of the fastest-growing segments of the computer industry in the latter half of the decade.</p>
  </div>
  <br><br>

</article>
<footer> &copy; 2017</footer>
</div>

</body>
</html>
